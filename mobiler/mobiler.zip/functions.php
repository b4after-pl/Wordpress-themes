<?php
require ('wp_bootstrap_navwalker.php');
add_action('after_setup_theme', 'mobiler_theme_setup');
function mobiler_theme_setup(){
    load_theme_textdomain('mobiler', get_template_directory() . '/languages');
	add_theme_support( 'post-thumbnails', array( 'page', 'post' ) ); 
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_editor_style();
}


if ( ! isset( $content_width ) ) {
	$content_width = 650;
}

// definitions 
define('MY_WORDPRESS_FOLDER',$_SERVER['DOCUMENT_ROOT']);
define('MY_THEME_FOLDER',dirname(__FILE__));
define('MY_THEME_PATH','/' .'wp-content/themes/mobiler');


///////////////////////////////
// custom post for sliders
///////////////////////////////
require_once(MY_THEME_FOLDER . '/lib/class-tgm-plugin-activation.php');
add_action( 'tgmpa_register', 'my_theme_register_required_plugins' );
/**
 * Register the required plugins for this theme.
 *
 * In this example, we register two plugins - one included with the TGMPA library
 * and one from the .org repo.
 *
 * The variable passed to tgmpa_register_plugins() should be an array of plugin
 * arrays.
 *
 * This function is hooked into tgmpa_init, which is fired within the
 * TGM_Plugin_Activation class constructor.
 */
function my_theme_register_required_plugins() {

    /**
     * Array of plugin arrays. Required keys are name and slug.
     * If the source is NOT from the .org repo, then source is also required.
     */
    $plugins = array(

        // This is an example of how to include a plugin pre-packaged with a theme.
        array(
            'name'               => 'Mobiler Sliders', // The plugin name.
            'slug'               => 'mobiler-sliders', // The plugin slug (typically the folder name).
            'source'             => get_stylesheet_directory() . '/lib/plugins/mobiler-sliders.zip', // The plugin source.
            'required'           => true, // If false, the plugin is only 'recommended' instead of required.
            'version'            => '', // E.g. 1.0.0. If set, the active plugin must be this version or higher.
            'force_activation'   => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch.
            'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins.
            'external_url'       => '', // If set, overrides default API URL and points to an external URL.
        ),

    );

    /**
     * Array of configuration settings. Amend each line as needed.
     * If you want the default strings to be available under your own theme domain,
     * leave the strings uncommented.
     * Some of the strings are added into a sprintf, so see the comments at the
     * end of each line for what each argument will be.
     */
    $config = array(
	
		'is_automatic' => true,
		'strings'      => array(
            'page_title'                      => __( 'Instaluj wymagane pluginy', 'mobiler' ),
            'menu_title'                      => __( 'Instaluj pluginy', 'mobiler' ),
            'installing'                      => __( 'Instalacja pluginu: %s', 'mobiler' ), // %s = plugin name.
            'oops'                            => __( 'Coś poszło nie tak z API plugiu.', 'mobiler' ),
            'notice_can_install_required'     => _n_noop( 'Ten motyw wymaga następującej wtyczki: %1$s.','Ten motyw wymaga następujących wtyczek: %1$s.', 'mobiler' ), // %1$s = plugin name(s).
            'notice_cannot_install'           => _n_noop( 'Niestety nie masz wystarczających uprawnień do instalacji wtyczki %s. Skontaktuj się z administratorem strony.', 'Niestety nie masz wystarczających uprawnień do instalacji wtyczek %s. Skontaktuj się z administratorem strony.', 'mobiler' ), // %1$s = plugin name(s).
            'notice_can_activate_required'    => _n_noop( 'Wymagana wtyczka jest nie aktywna: %1$s.', 'Wymagane wtyczki nie są aktywne: %1$s.', 'mobiler' ), // %1$s = plugin name(s).
            'notice_cannot_activate'          => _n_noop( 'Niestety nie masz wystarczających uprawnień do aktywacji wtyczki %s. Skontaktuj się z administratorem strony.', 'Niestety nie masz wystarczających uprawnień do aktywacji wtyczek %s. Skontaktuj się z administratorem strony.', 'mobiler' ), // %1$s = plugin name(s).
            'install_link'                    => _n_noop( 'Rozpocznij instalację wtyczki', 'Rozpocznij instalację wtyczek','mobiler' ),
            'activate_link'                   => _n_noop( 'Aktywuj wtyczkę', 'Aktywuj wtyczki','mobiler' ),
            'return'                          => __( 'Powrót do instalatora wymaganych wtyczek', 'mobiler' ),
            'plugin_activated'                => __( 'Wtyczka aktywowana pomyślnie', 'mobiler' ),
			'dismiss'						  => __( 'Zamknij to przypomnienie.', 'mobiler' ),
            'complete'                        => __( 'Wtyczka %s została zainstalowana i aktywowana pomyślnie. ', 'mobiler' ), // %s = dashboard link.
            'nag_type'                        => 'updated' // Determines admin notice type - can only be 'updated', 'update-nag' or 'error'.
        )
	);

    tgmpa( $plugins, $config );

}

///////////////////////////////
// menus
///////////////////////////////

include (MY_THEME_FOLDER . '/inc/menus.inc.php');

///////////////////////////////
// thumbs theme support
///////////////////////////////

add_theme_support( 'post-thumbnails', array( 'slider', 'post', 'page' ) );

///////////////////////////////
// custom thumb sizes
///////////////////////////////

add_image_size( 'homepage-carusel', 1170, 500, true );

add_image_size( 'homepage-carusel-wide', 1600, 500, true );
add_image_size( 'theme-logo', 230, 400, false );
///////////////////////////////
// theme settings
///////////////////////////////
add_action('admin_enqueue_scripts', 'mobiler_admin_scripts');
 
function mobiler_admin_scripts() {
        wp_enqueue_media();
		wp_enqueue_style( 'mobiler-admin', get_template_directory_uri().'/css/mobiler-admin.css' );
        wp_register_script('my-admin-js', MY_THEME_PATH.'/js/my-admin.js', array('jquery'));
        wp_enqueue_script('my-admin-js');
    
}
include(MY_THEME_FOLDER . '/inc/themeSettings.inc.php');

/////////////////////////////////
// own widgets 
/////////////////////////////////

include(MY_THEME_FOLDER . '/inc/mobilerWidgets.inc.php');

/////////////////////////////////
// custom comments
/////////////////////////////////

include (MY_THEME_FOLDER .'/inc/comments.inc.php');
