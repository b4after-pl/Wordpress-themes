	<div <?php post_class( 'row' ); ?>>
		<?php if(has_post_thumbnail()): ?>
		<div class="col-xs-2">
		  <?php echo get_the_post_thumbnail($post->ID, 'thumbnail', array('class'=>'img-responsive')); ?>
		  <?php the_time('j F Y'); ?>
        </div>
		<?php endif; ?>
        <div class="col-xs-<?php echo(has_post_thumbnail())?'10':'12'?> post-content">
          <h2><a href="<?php echo get_permalink(); ?>" title="<?php echo get_the_title(); ?>"><?php echo get_the_title(); ?></a></h2>
		  <span class="meta"><?php echo __('Aktualność znajduje się w kategorii:', 'mobiler'); ?> <?php the_category(', '); ?></span>
		  <span class="meta"><?php the_tags(); ?></span>
          <p class="lead"><?php the_content(); ?></p>
		  <?php
			$defaults = array(
				'before'           => '<div class="row">' . __( 'Strony:', 'mobiler' ),
				'after'            => '</div>',
				'link_before'      => '',
				'link_after'       => '',
				'next_or_number'   => 'number',
				'separator'        => ' ',
				'nextpagelink'     => __( 'Następna strona', 'mobiler' ),
				'previouspagelink' => __( 'Poprzednia strona', 'mobiler' ),
				'pagelink'         => '%',
				'echo'             => 1
			);
		 
			wp_link_pages( $defaults );

		?>
        </div>
	</div>
	<hr class="featurette-divider">