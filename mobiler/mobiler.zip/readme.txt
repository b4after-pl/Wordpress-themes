=== mobileR ===
Contributors: dactive.pl Team
Tags: black, gray, white, dark, light, two-columns, left-sidebar, responsive-layout, accessibility-ready, custom-menu, editor-style, featured-images, post-formats, rtl-language-support, threaded-comments, translation-ready
Requires at least: 4.1
Tested up to: 4.1
Stable tag: 4.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Mobiler is full responsive WordPress theme that display Your site correctly on any device (smartphone, tablet, large pc monitor or laptop). It provides sliders on frontpage feature and many customization options.

* Responsive Layout
* Social Links
* The GPL v2.0 or later license. :) Use it to make something cool.

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's ZIP file. Click Install Now.
3. Click Activate to use your new theme right away.