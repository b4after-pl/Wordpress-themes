<?php
/**
 * Plugin Name: Mobiler Sliders
 * Description: Add homepage sliders feature to mobileR theme.
 * Version: 0.1
 * Author: dactive.pl
 * Author URI: https://www.dactive.pl/blog/mobiler-darmowy-szablon-wordpress/
 */


// ===================================================================================
// ======================================================================= Slidery
// ===================================================================================
add_action('init', 'item_register');

function item_register() {

$labels = array(
			'name'               => __( 'Slidery', 'mobiler' ),
			'singular_name'      => __( 'Slider', 'mobiler' ),
			'menu_name'          => __( 'Slidery', 'mobiler' ),
			'name_admin_bar'     => __( 'Slider', 'mobiler' ),
			'add_new'            => __( 'Dodaj nowy', 'mobiler' ),
			'add_new_item'       => __( 'Dodaj nowy slider', 'mobiler' ),
			'new_item'           => __( 'Nowy slider', 'mobiler' ),
			'edit_item'          => __( 'Edytuj slider', 'mobiler' ),
			'view_item'          => __( 'Zobacz slider', 'mobiler' ),
			'all_items'          => __( 'Wszystkie slidery', 'mobiler' ),
			'search_items'       => __( 'Wyszukaj slider', 'mobiler' ),
			'parent_item_colon'  => __( 'Sldiery nadrzędne:', 'mobiler' ),
			'not_found'          => __( 'Nie znaleziono slidera.', 'mobiler' ),
			'not_found_in_trash' => __( 'Nie znaleziono slidera w koszu.', 'mobiler' )
	);

$args = array(
    	'labels' => $labels,
    	'singular_label' => __('Slider', 'mobiler'),
    	'public' => true,
    	'show_ui' => true,
    	'capability_type' => 'post',
    	'hierarchical' => false,
    	'rewrite' => true,
    	'supports' => array('title', 'thumbnail')
    );

	register_post_type( 'slider' , $args );
}

function slider_options() {
	global $post;
	$custom = get_post_custom($post->ID);
    $slider_order = $custom["slider_order"][0];
	$slider_podpis = $custom["slider_podpis"][0];
	$slider_link = $custom["slider_link"][0];
	$slider_color = $custom["slider_color"][0];
	$slider_align = $custom["slider_align"][0];
	$slider_link_text = $custom["slider_link_text"][0];
	?>
    <table width="100%" cellpadding="2" cellspacing="2">
        <tr>
            <td style="width: 15%"><label><?php echo __( 'Podpis:', 'mobiler') ?></label></td>
            <td><input type="text" name="slider_podpis" value="<?php echo esc_attr( $slider_podpis ); ?>" size="80" style="width:80%" /></td>
        </tr>
        <tr>
            <td style="width: 15%"><label><?php echo __( 'Link:', 'mobiler') ?></label></td>
            <td><input type="text" name="slider_link" value="<?php echo esc_attr( $slider_link ); ?>" size="80" style="width:80%" /></td>
        </tr>
		 <tr>
            <td style="width: 15%"><label><?php echo __( 'Treść linku:', 'mobiler') ?></label></td>
            <td><input type="text" name="slider_link_text" value="<?php echo esc_attr( $slider_link_text ); ?>" size="80" style="width:80%" /></td>
        </tr>
        <tr>
            <td style="width: 15%"><label><?php echo __( 'Kolejność:', 'mobiler') ?></label></td>
            <td><input type="text" name="slider_order" value="<?php echo esc_attr( $slider_order ); ?>" size="80" style="width:80%" /></td>
        </tr>
		<tr>
            <td style="width: 15%"><label><?php echo __( 'Kolorystyka:', 'mobiler') ?></label></td>
            <td>
				<select name="slider_color">
					<option value="light" <?php echo ($slider_color=='light')?'selected':''?>><?php echo __( 'jasna', 'mobiler') ?></option>
					<option value="dark"<?php echo ($slider_color=='dark')?'selected':''?>><?php echo __( 'ciemna', 'mobiler') ?></option>
				</select>
        </tr>
		<tr>
            <td style="width: 15%"><label><?php echo __( 'Wyrównanie:', 'mobiler') ?></label></td>
            <td>
				<select name="slider_align">
					<option value="carousel-caption-left" <?php echo ($slider_align=='carousel-caption-left')?'selected':''?>><?php echo __( 'do lewej', 'mobiler') ?></option>
					<option value="carousel-caption-right"<?php echo ($slider_align=='carousel-caption-right')?'selected':''?>><?php echo __( 'do prawej', 'mobiler') ?></option>
				</select>
        </tr>
    </table>
	
	<div style="background-color: #e3e3e3; color: #000; margin: 20px; padding: 20px">
		<?php echo __('Uwaga! Aby dodać obrazek slidera użyj do tego celu obrazka wyróżniającego (ikona wpisu) znajdującego się w prawym panelu.', 'mobiler'); ?>
	</div>
	<?php 
}

function save_slider_data() {
	global $post;
	update_post_meta($post->ID, "slider_order", $_POST["slider_order"]);
	update_post_meta($post->ID, "slider_podpis", $_POST["slider_podpis"]);
	update_post_meta($post->ID, "slider_link", $_POST["slider_link"]);
	update_post_meta($post->ID, "slider_color", $_POST["slider_color"]);
	update_post_meta($post->ID, "slider_align", $_POST["slider_align"]);
	update_post_meta($post->ID, "slider_link_text", $_POST["slider_link_text"]);
}

add_action('save_post', 'save_slider_data');

function slider_edit_columns($columns) {

	$columns = array(
		"cb" => "<input type=\"checkbox\" />",
		"title" => __('Nagłówek', 'mobiler'),
		"slider_caption" => __('Opis', 'mobiler'),
		"slider_order" => __('Kolejność', 'mobiler'),
		"slider_link" => __('Odnośnik', 'mobiler')
	);
	return $columns;
}

add_action("manage_slider_posts_custom_column",  "slider_custom_columns");

function add_customs_info() {
	add_meta_box("SliderInfo-meta",  __( 'Opis', 'mobiler') , "slider_options", "slider", "normal", "low");
}



add_filter( 'manage_edit-slider_columns', 'my_edit_slider_columns' ) ;

function my_edit_slider_columns( $columns ) {

	$columns = array(
		'cb' => '<input type="checkbox" />',
		'title' => __('Tytuł', 'mobiler'),
		'slider_order' => __('Kolejność', 'mobiler'),
		'date' => __('Data', 'mobiler')
	);

	return $columns;
}

add_action("manage_slider_posts_custom_column",  "slider_custom_columns");
			


function slider_custom_columns($columns) {

	global $post;
	switch ($columns) {

		case "slider_order":
			$custom = get_post_custom();
			echo $custom["slider_order"][0];
			break;

	}
}

add_filter( 'manage_edit-slider_sortable_columns', 'mobiler_slider_sortable_columns' );

function mobiler_slider_sortable_columns( $columns ) {

	$columns['slider_order'] = 'slider_order';

	return $columns;
}

add_action("admin_init", "add_customs_info");